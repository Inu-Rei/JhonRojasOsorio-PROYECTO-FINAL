import {useEffect, useState} from 'react'
import { useParams } from 'react-router-dom'
import { unicoPersonaje } from '../funciones/funciones'

const Personaje = () => {
  const [personaje, setPersonaje] = useState(null)

const params = useParams()
useEffect(()=>{
  unicoPersonaje(params.id, setPersonaje)
},[])
  return (
    <>
    <h2>Personaje con el id {params.id}</h2>
    <img src={personaje?.image} alt=""/>
    <h2>Personaje con el id {params.id}</h2>
    <p>con el nombre {personaje?.name}</p>
    <p>Genero: {personaje?.gender}</p>
    <p>Locación: {personaje?.location.name}</p>
    </>
  )
}

export default Personaje
